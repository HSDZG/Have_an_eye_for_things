
// tfL系列函数的注释数据
const tfL_fundata=[
    {
        fname:"tfL_isprnum",
        fspeak:"判断素数，返回逻辑值",
        fparam:["要判断的数字，默认1"]
    }, // 姓名,说明,参数说明
    {
        fname:"tfL_gictocina",
        fspeak:"将逻辑值转换为（true）是与不是（false）",
        fparam:["逻辑值，true或false，默认为false"]
    },
    {
        fname:"tfL_Fipoachoo",
        fspeak:"返回斐波拉切指定项数的值",
        fparam:["斐波拉切项数，默认1"]
    },
    {
        fname:"tfL_max_comDor",
        fspeak:"返回两个数的最大公约数",
        fparam:["第一个数字，默认12","第二个数字，默认36"]
    },
    {
        fname:"tfL_min_comPe",
        fspeak:"返回两个数的最小公倍数",
        fparam:["第一个数字，默认36","第二个数字，默认6"]
    },
    {
        fname:"tfL_NumStrToFop",
        fspeak:"从字符串中提取数字运算，并返回结果",
        fparam:["有数字的字符串，如果没有找到，结果会是0（+，-）或1（*，/）","运算符， 只能为+，-，*，/，否则会返回error"]
    },
    {
        fname:"tfL_substrinmastr",
        fspeak:"查看主字符串中是否包含子字符串，大写小写分开匹配",
        fparam:["子字符串","主字符串"]
    },
    {
        fname:"tfL_subinmastrcou",
        fspeak:"统计子字符串在主字符串中出现的次数，没有出现返回0",
        fparam:["子字符串","主字符串"]
    },
    {
        fname:"tfL_strsu1tosu2",
        fspeak:"提取字符串中sub1开始到sub2的子字符串，不包括sub1和sub2，如果sub1或sub2不在字符串中，将返回error",
        fparam:["要提取的字符串","开始的字符串","结束的字符串"]
    },
    {
        fname:"tfL_type_conve",
        fspeak:"类型转换，将任何值转换成你想要的类型，并返回转换结果",
        fparam:["要转换的值，默认str","类型，默认string，取值为string，number，bool，int，float中的一种，如果都不对应，将不进行转换，返回原本值"]
    },
    {
        fname:"tfL_strEftOrRight",
        fspeak:"将字符串左移或右移指定位，例如udentst右移动两位变为student",
        fparam:["要移动的字符串，默认str","逻辑值，默认true，true为向左移动，false为向右移动","左移或右移几位，必须大于等于1，否则返回error，默认1，如果超过字符串长度将会不移动"]
    },
    {
        fname:"tfL_repStr",
        fspeak:"将一个字符串重复指定次数",
        fparam:["要重复的字符串，默认str","次数，默认2"]
    },
    {
        fname:"tfL_numDig",
        fspeak:"求出数字的总位数，不包含小数",
        fparam:["求位数的数字，默认100"]
    },
    {
        fname:"tfL_DigSep",
        fspeak:"数位分离，分离出指定位数的数字，只分离整数位",
        fparam:["要分离数位的数字，默认123","位数，指的是从右向左多少位，必须大于0，否则返回error，默认2"]
    },
    {
        fname:"tfL_withStrHomanum",
        fspeak:"提取字符串中指定组数的数字",
        fparam:["要提取数字的字符串，默认24Greater than12","第几组数字，如果小于等于0将返回error，如果没找到将返回0，默认2"]
    },
    {
        fname:"tfL_gar_ar_per",
        fspeak:"求圆的面积或周长",
        fparam:["圆的半径，默认为3","逻辑值，true则为周长，否则为面积，默认为true"]
    },
    {
        fname:"tfL_qua_ar_per",
        fspeak:"计算四边形的面积或周长",
        fparam:["宽度，默认为40","高度，默认为20","逻辑值，true则为周长，否则为面积，默认为true"]
    },
    {
        fname:"tfL_BCDcodetodec",
        fspeak:"将BCD码字符串转换为十进制数，包含小数，并且允许出现其他字符，如111 1000 . 1000 0111=78.87",
        fparam:["BCD码字符串，默认值111 1000 . 1000 0111"]
    },
    {
        fname:"tfL_IPv4LB",
        fspeak:"判断IPv4地址属于哪个类别（A，B，C，D，E，私有，回环）",
        fparam:["要判断的IPv4地址，默认127.0.0.1"]
    },
    {
        fname:"tfL_IPv4net",
        fspeak:"通过IPv4地址和其子网掩码求其网络号",
        fparam:["IPv4地址，默认127.0.0.1","子网掩码，默认255.255.0.0"]
    },
    {
        fname:"tfL_IPv4host",
        fspeak:"通过IPv4地址和其子网掩码求其主机号",
        fparam:["IPv4地址，默认127.0.0.1","子网掩码，默认255.255.0.0"]
    },
    {
        fname:"tfL_IPv4broadrss",
        fspeak:"通过IPv4地址和其子网掩码求其广播地址",
        fparam:["IPv4地址，默认127.0.0.1","子网掩码，默认255.255.0.0"]
    },
    {
        fname:"tfL_IPv4subnetsk",
        fspeak:"根据IPv4地址和子网数量求其子网掩码",
        fparam:["IPv4地址，默认127.0.0.1","子网数量，默认24"]
    },
    {
        fname:"tfL_isoddoreven",
        fspeak:"判断数字是否是偶数或奇数，偶数为真，奇数为假",
        fparam:["要判断的数字，默认2024"]
    }
]




// 虽然是全局变量，但是只使用一次，这只是初始化，加快添加函数速度
var tfL_fun_string="";
for (i=0;i<=tfL_fundata.length-1;i++)
{
    tfL_fun_string+=eval(tfL_fundata[i].fname+".toString();")+"\n\n";
}



// 界面单击事件的数据
const U_Action_config={
    HY_addfun:function ()
    {
        let i;
        // 获取插入的模块中的第一行字符串
        if (Application.JSIDE.SelectedJSComponent.CodeModule.Lines(1,1).indexOf(tfL_fundata[0].fname) === -1)
        {
        // 利用 Application.JSIDE接口，实现jsa函数的插入
        // 但因为安全因素，用户需要自主打开 工具-->宏安全性-->可靠发行商-->勾选 “信任对于‘wpsjs 项目‘ 的访问
            Application.JSIDE.SelectedJSComponent.CodeModule.AddFromString(tfL_fun_string);
            for(i=0;i<=tfL_fundata.length-1;i++)
            {
                // 添加函数说明
                Application.MacroOptions(tfL_fundata[i].fname, tfL_fundata[i].fspeak,
                    undefined,
                    undefined,
                    undefined,
                    undefined,
                    "慧眼识务tfL系列函数",
                    undefined,
                    undefined,
                    undefined,
                    tfL_fundata[i].fparam);
            }
            confirm("tfL系列函数明添加成功，总计"+tfL_fundata.length.toString()+"个函数");
        }
        else
        {
            confirm("你已添加tfL系列函数");
        }
    },
    HY_user_config:function ()
    {
        let taskPane = Application.CreateTaskPane(GetUrlPath()+"/HTMquest/user_constdata_config.html");
        taskPane.DockPosition = 0;
        taskPane.Visible = true;
    },
    HY_user_acqu_config:function ()
    {
        defne_userData();
        Application.PluginStorage.setItem("userData", JSON.stringify(user_data));
        confirm("重置参数成功");
    },
    HY_random_number:function ()
    {
        user_data=JSON.parse(Application.PluginStorage.getItem("userData"));
        let seasize=Application.Selection;
        let i,j,k;
        // 单一区域情况
        if(Application.Selection.Areas.Count<=1)
        {
            for (i = 1; i <= seasize.Rows.Count; i++)
            {
                for (j = 1; j <= seasize.Columns.Count; j++) Application.Selection.Cells.Item(i, j).Value2 = randNtoM(user_data.randomStrart, user_data.randomEnd);
            }
        }
        else   // 多区域情况
        {
            for(i=1;i<=Application.Selection.Areas.Count;i++)
            {
                let seassize=Application.Selection.Areas.Item(i);
                for(j = 1; j <= seassize.Rows.Count; j++)
                {
                    for (k = 1; k <= seassize.Columns.Count; k++) Application.Selection.Areas.Item(i).Cells.Item(j, k).Value2 = randNtoM(user_data.randomStrart, user_data.randomEnd);
                }
            }
        }
    },
    HY_random_one:function ()
    {
        let prizeP=[],prizepsize=0;
        let prizeresu=0;
        let i,j,k;
        let seasize=Application.Selection;
        // 单一区域情况
        if(Application.Selection.Areas.Count<=1)
        {
            for (i = 1; i <= seasize.Rows.Count; i++)
            {
                for (j = 1; j <= seasize.Columns.Count; j++)
                {
                    prizeP[prizepsize]=Application.Selection.Cells.Item(i, j).Value2;
                    prizepsize++;
                }
            }
        }
        else   // 多区域情况
        {
            for(i=1;i<=Application.Selection.Areas.Count;i++)
            {
                let seassize=Application.Selection.Areas.Item(i);
                for(j = 1; j <= seassize.Rows.Count; j++)
                {
                    for (k = 1; k <= seassize.Columns.Count; k++)
                    {
                        prizeP[prizepsize]=Application.Selection.Areas.Item(i).Cells.Item(j, k).Value2;
                        prizepsize++;
                    }
                }
            }
        }
        console.log(prizeP);

        prizeresu=randNtoM(0,prizepsize-1);
        console.log(prizeresu);
        confirm("恭喜抽到了  "+prizeP[prizeresu]);
    },
    HY_sequ_engsh:function ()
    {
        user_data=JSON.parse(Application.PluginStorage.getItem("userData"));
        let seasize=Application.Selection;

        // 要转换成字母的数字 单区域情况
        let toAB_number=1;
        // 多区域情况
        let toAB_numbers=[];
        let i,j,k;
        // 单一区域情况
        if(Application.Selection.Areas.Count<=1)
        {
            if (user_data.user_sequ_dire===1)
            {
                for (i = 1; i <= seasize.Rows.Count; i++)
                {
                    for (j = 1; j <= seasize.Columns.Count; j++)
                    {
                        Application.Selection.Cells.Item(i, j).Value2 = num_to_ABC(toAB_number,user_data.user_sequ_big_sma);
                        toAB_number++;
                    }
                }
            }
            else
            {
                for (j = 1; j <= seasize.Columns.Count; j++)
                {
                    for (i = 1; i <= seasize.Rows.Count; i++)
                    {
                        Application.Selection.Cells.Item(i, j).Value2 = num_to_ABC(toAB_number,user_data.user_sequ_big_sma);
                        toAB_number++;
                    }
                }
            }
        }
        else   // 多区域情况
        {
            toAB_numbers=new Array(Application.Selection.Areas.Count);
            for(i=1;i<=Application.Selection.Areas.Count;i++)
            {
                toAB_numbers[i]=1;
                let seassize=Application.Selection.Areas.Item(i);

                if (user_data.user_sequ_dire===1)
                {
                    for(j = 1; j <= seassize.Rows.Count; j++)
                    {
                        for (k = 1; k <= seassize.Columns.Count; k++)
                        {
                            Application.Selection.Areas.Item(i).Cells.Item(j, k).Value2 =num_to_ABC(toAB_numbers[i],user_data.user_sequ_big_sma);
                            toAB_numbers[i]++;
                        }
                    }
                }
                else
                {
                     for (k = 1; k <= seassize.Columns.Count; k++)
                    {
                        for(j = 1; j <= seassize.Rows.Count; j++)
                        {
                            Application.Selection.Areas.Item(i).Cells.Item(j, k).Value2 =num_to_ABC(toAB_numbers[i],user_data.user_sequ_big_sma);
                            toAB_numbers[i]++;
                        }
                    }
                }
            }
        }
    },
    HY_sequ_roman:function ()
    {
        user_data=JSON.parse(Application.PluginStorage.getItem("userData"));
        let seasize=Application.Selection;

        // 要转换成罗马数字的数字
        let T_roma_number=1;
        let T_roma_numbers=[];
        let i,j,k;
        // 单一区域情况
        if(Application.Selection.Areas.Count<=1)
        {
            if((seasize.Rows.Count*seasize.Columns.Count)>=4000)
            {
                confirm("你选择的区域最大值超过3999的最大罗马数字");
                return;
            }
            if (user_data.user_sequ_dire===1)
            {
                for (i = 1; i <= seasize.Rows.Count; i++)
                {
                    for (j = 1; j <= seasize.Columns.Count; j++)
                    {
                        Application.Selection.Cells.Item(i, j).Value2 = intToRoman(T_roma_number);
                        T_roma_number++;
                    }
                }
            }
            else
            {
                for (j = 1; j <= seasize.Columns.Count; j++)
                {
                    for (i = 1; i <= seasize.Rows.Count; i++)
                    {
                        Application.Selection.Cells.Item(i, j).Value2 = intToRoman(T_roma_number);
                        T_roma_number++;
                    }
                }
            }
        }
        else   // 多区域情况
        {
            T_roma_numbers=new Array(Application.Selection.Areas.Count);
            for(i=1;i<=Application.Selection.Areas.Count;i++)
            {
                T_roma_numbers[i]=1;
                let seassize=Application.Selection.Areas.Item(i);

                if((seassize.Rows.Count*seassize.Columns.Count)>=4000)
                {
                    confirm("你选择的区域最大值超过3999的最大罗马数字");
                    return;
                }

                if (user_data.user_sequ_dire===1)
                {
                    for(j = 1; j <= seassize.Rows.Count; j++)
                    {
                        for (k = 1; k <= seassize.Columns.Count; k++)
                        {
                            Application.Selection.Areas.Item(i).Cells.Item(j, k).Value2 =intToRoman(T_roma_numbers[i]);
                            T_roma_numbers[i]++;
                        }
                    }
                }
                else
                {
                    for (k = 1; k <= seassize.Columns.Count; k++)
                    {
                        for(j = 1; j <= seassize.Rows.Count; j++)
                        {
                            Application.Selection.Areas.Item(i).Cells.Item(j, k).Value2 =intToRoman(T_roma_numbers[i]);
                            T_roma_numbers[i]++;
                        }
                    }
                }
            }
        }
    },
    HY_cata_insert:function ()
    {

        if (Application.Worksheets.Item(cata_isadd_name)==null)
        {
            Application.Worksheets.Add(Application.Worksheets.Item(1), null, 1).Name = cata_isadd_name;
            // 目录表添加区域
            let MTAB = Application.Worksheets.Item(1).Range("A1:B" + (Application.Worksheets.Count - 1).toString());
            let i;

            MTAB.Cells.Item(1, 1).Value2 = "序号";
            MTAB.Cells.Item(1, 2).Value2 = "工作表";

            // 添加序号
            for (i = 1; i <= MTAB.Rows.Count; i++) MTAB.Cells.Item(i + 1, 1).Value2 = i;

            // 添加工作表链接
            for (i = 1; i <= MTAB.Rows.Count; i++)
            {
                MTAB.Cells.Item(i + 1, 2).Hyperlinks.Add(
                    MTAB.Cells.Item(i + 1, 2), "",
                    Application.Worksheets.Item(i + 1).Name + "!A1",
                    "", Application.Worksheets.Item(i + 1).Name);
            }

            // 添加返回目录
            for (i = 1; i <= Application.Worksheets.Count - 1; i++)
            {
                if (Application.Worksheets.Item(i + 1).Range("A1").Value2 != null)
                {
                    Application.Worksheets.Item(i + 1).Range("1:1").Insert(-4121, undefined);
                }
                Application.Worksheets.Item(i + 1).Range("A1").Hyperlinks.Add(
                    Application.Worksheets.Item(i + 1).Range("A1"), "",
                    Application.Worksheets.Item(1).Name + "!A1",
                    "", "返回目录表");
            }
        }
        else
        {
            confirm("你已添加目录表");
        }
    },
    HY_cata_update:function ()
    {
        if (Application.Worksheets.Item(cata_isadd_name)!=null)
        {
            // 目录表添加区域
            let MTAB = Application.Worksheets.Item(1).Range("A1:B" + (Application.Worksheets.Count - 1).toString());
            let i;

            MTAB.Cells.Item(1, 1).Value2 = "序号";
            MTAB.Cells.Item(1, 2).Value2 = "工作表";

            // 添加序号
            for (i = 1; i <= MTAB.Rows.Count; i++) MTAB.Cells.Item(i + 1, 1).Value2 = i;

            // 添加工作表链接
            for (i = 1; i <= MTAB.Rows.Count; i++)
            {
                MTAB.Cells.Item(i + 1, 2).Hyperlinks.Add(
                    MTAB.Cells.Item(i + 1, 2), "",
                    Application.Worksheets.Item(i + 1).Name + "!A1",
                    "", Application.Worksheets.Item(i + 1).Name);
            }

            // 添加返回目录
            for (i = 1; i <= Application.Worksheets.Count - 1; i++)
            {
                if (Application.Worksheets.Item(i + 1).Range("A1").Value2 != null
                &&
                    Application.Worksheets.Item(i + 1).Range("A1").Value2!=="返回目录表")
                {
                    Application.Worksheets.Item(i + 1).Range("1:1").Insert(-4121, undefined);
                }
                Application.Worksheets.Item(i + 1).Range("A1").Hyperlinks.Add(
                    Application.Worksheets.Item(i + 1).Range("A1"), "",
                    Application.Worksheets.Item(1).Name + "!A1",
                    "", "返回目录表");
            }
            confirm("更新目录表完成");
        }
        else
        {
            confirm("你还没有添加目录表");
        }
    },
    HY_cata_dete:function ()
    {
        if (Application.Worksheets.Item(cata_isadd_name)!=null)
        {
            let i;
            Application.Worksheets.Item(cata_isadd_name).Delete();
            for (i = 1; i <= Application.Worksheets.Count; i++)
            {
                Application.Worksheets.Item(i).Range("A1").Hyperlinks.Delete();
                Application.Worksheets.Item(i).Range("A1").Value2="";
            }
        }
        else
        {
            confirm("你还没有添加目录表");
        }
    },
    HY_about:function ()
    {
        let taskPane = Application.CreateTaskPane(GetUrlPath()+"/HTMquest/HY_about.html");
        taskPane.DockPosition = 2;
        taskPane.Visible = true;
    },
    HY_hep:function ()
    {
        let taskPane = Application.CreateTaskPane(GetUrlPath()+"/HTMquest/HY_hep.html");
        taskPane.DockPosition = 2;
        taskPane.Visible = true;
    }
}

// 界面图片的数据
const U_mag_config= {
    HY_addfun: "images/添加.png",
    HY_user_config:"images/用户配置.png",
    HY_user_acqu_config:"images/重置.png",
    HY_random:"images/随机.png",
    HY_random_number:"images/随机数.png",
    HY_random_one:"images/随机抽取.png",
    HY_sequ:"images/序列.png",
    HY_sequ_engsh:"images/英文序列.png",
    HY_sequ_roman:"images/罗马序列.png",
    HY_cata:"images/目录表.png",
    HY_cata_insert:"images/插入目录表.png",
    HY_cata_update:"images/更新目录表.png",
    HY_cata_dete:"images/删除目录表.png",
    HY_about:"images/关于.png",
    HY_hep:"images/帮助.png",
    mag_mr:"images/默认.png"
}