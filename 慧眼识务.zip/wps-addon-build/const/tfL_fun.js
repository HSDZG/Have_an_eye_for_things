

/**
 * 判断数字是否是偶数或奇数，偶数为真，奇数为假
 * @param {Number} num - 要判断的数字，默认2024
 * @returns {boolean} 偶数返回true，奇数返回false
 */
function tfL_isoddoreven(num=2024)
{
	num=Number(num);
	if(num%2===0) return true;
	return false;
}


/**
 * 根据IPv4地址和子网数量求其子网掩码
 * @param {String} Padrss - IPv4地址，默认127.0.0.1
 * @param {Number} num - 子网数量，默认24
 * @returns {string} IPv4地址划分出num个子网的子网掩码
 */
  function tfL_IPv4subnetsk(Padrss="127.0.0.1", num=24)
{
    Padrss=Padrss.toString();
	num=parseInt(num);
	let i,address="",re="";
	for(i=0;i<Padrss.length;i++)
	{
		if(Padrss[i]>="0"&&Padrss[i]<="9"||Padrss[i]===".")
		address+=Padrss[i];
	}
	let addnum=address.split(".");
	if(addnum.length!==4) return "error";
	for(i=0;i<=3;i++) if(addnum[i]<0||addnum[i]>255) return "error";
	let wnum=0;
	if(addnum[0]>=0&&addnum[0]<=127) wnum=8;
	else if(addnum[0]>=128&&addnum[0]<=191) wnum=16;
	else if(addnum[0]>=192&&addnum[0]<=223) wnum=24;
	else return "error";
	let zwnum=0;
	while(true)
	{
		if(Math.pow(2,zwnum)>=num) break;
		zwnum++;
	}
	wnum+=zwnum;
	if(wnum>=32) return "error";
	let dy=wnum%8,notdy=parseInt(wnum/8),netid=String(255^(Math.pow(2,8-dy)-1)); // 多余的子网号，默认的子网号，划分的子网掩码
	if(notdy===1) re+="255."+netid+".0.0";
	else if(notdy===2) re+="255.255."+netid+".0";
	else if(notdy===3) re+="255.255.255."+netid;
	return re;
}



/**
 * 通过IPv4地址和其子网掩码求其广播地址
 * @param {String} Padrss - IPv4地址，默认127.0.0.1
 * @param {String} subnet - 子网掩码，默认255.255.0.0
 * @returns {string} IPv4地址的广播地址
 */
  function tfL_IPv4broadrss(Padrss="127.0.0.1", subnet="255.255.0.0")
{
    Padrss=Padrss.toString();
	subnet=subnet.toString();
	let i,address="",sub="";
	for(i=0;i<Padrss.length;i++)
	{
		if(Padrss[i]>="0"&&Padrss[i]<="9"||Padrss[i]===".")
		address+=Padrss[i];
	}
	for(i=0;i<subnet.length;i++)
	{
		if(subnet[i]>="0"&&subnet[i]<="9"||subnet[i]===".")
		sub+=subnet[i];
	}
	let addnum=address.split(".");
	let subnum=sub.split(".");
	if(addnum.length!==4||subnum.length!==4) return "error";
	for(i=0;i<=3;i++)
	{
		if(addnum[i]<0||addnum[i]>255||subnum[i]<0||subnum[i]>255) return "error";
	}
	let re="",k=0;
	for(i=0;i<=3;i++)
	{
		k=(addnum[i]&subnum[i])+(255-parseInt(subnum[i])); // 这里不用取反的原因是考虑到机器位可能是32位及更高位，取反可能会得到负数
		re+=k.toString();
		if(i<=2) re+=".";
	}
	return re;
}



/**
 * 通过IPv4地址和其子网掩码求其主机号
 * @param {String} Padrss - IPv4地址，默认127.0.0.1
 * @param {String} subnet - 子网掩码，默认255.255.0.0
 * @returns {string} IPv4地址的主机号
 */
   function tfL_IPv4host(Padrss="127.0.0.1", subnet="255.255.0.0")
{
    Padrss=Padrss.toString();
	subnet=subnet.toString();
	let i,address="",sub="";
	for(i=0;i<Padrss.length;i++)
	{
		if(Padrss[i]>="0"&&Padrss[i]<="9"||Padrss[i]===".")
		address+=Padrss[i];
	}
	for(i=0;i<subnet.length;i++)
	{
		if(subnet[i]>="0"&&subnet[i]<="9"||subnet[i]===".")
		sub+=subnet[i];
	}
	let addnum=address.split(".");
	let subnum=sub.split(".");
	if(addnum.length!==4||subnum.length!==4) return "error";
	for(i=0;i<=3;i++)
	{
		if(addnum[i]<0||addnum[i]>255||subnum[i]<0||subnum[i]>255) return "error";
	}

	let re="",k=0;
	for(i=0;i<=3;i++)
	{
		k=addnum[i]&(~subnum[i]);  // 这里用取反的原因是就算字长为32位及更高，也会因为前面的主机号只有8位而忽略
		re+=k.toString();
		if(i<=2) re+=".";
	}
	return re;
}


/**
 * 通过IPv4地址和其子网掩码求其网络号
 * @param {String} Padrss - IPv4地址，默认127.0.0.1
 * @param {String} subnet - 子网掩码，默认255.255.0.0
 * @returns {string} IPv4地址的网络号
 */
   function tfL_IPv4net(Padrss="127.0.0.1", subnet="255.255.0.0")
{
    Padrss=Padrss.toString();
	subnet=subnet.toString();
	let i,address="",sub="";
	for(i=0;i<Padrss.length;i++)
	{
		if(Padrss[i]>="0"&&Padrss[i]<="9"||Padrss[i]===".")
		address+=Padrss[i];
	}
	for(i=0;i<subnet.length;i++)
	{
		if(subnet[i]>="0"&&subnet[i]<="9"||subnet[i]===".")
		sub+=subnet[i];
	}
	let addnum=address.split(".");
	let subnum=sub.split(".");
	if(addnum.length!==4||subnum.length!==4) return "error";
	for(i=0;i<=3;i++)
	{
		if(addnum[i]<0||addnum[i]>255||subnum[i]<0||subnum[i]>255) return "error";
	}
	let re="",k=0;
	for(i=0;i<=3;i++)
	{
		k=addnum[i]&subnum[i];
		re+=k.toString();
		if(i<=2) re+=".";
	}
	return re;
}


/**
 * 判断IPv4地址属于哪个类别（A，B，C，D，E，私有，回环）
 * @param {String} Padrss - 要判断的IPv4地址，默认127.0.0.1
 * @returns	{string} IPv4地址的类别
 */
   function tfL_IPv4LB(Padrss="127.0.0.1")
{
	Padrss=Padrss.toString();
    // 提取数字和小数点
    let legalIP = "";
	let i;
    for ( i = 0; i < Padrss.length; i++)
	{
        if (Padrss[i] >= "0" && Padrss[i] <= "9" || Padrss[i] === ".")
		{
            legalIP += Padrss[i];
        }
    }

    // 判断IP地址类别
    let parts = legalIP.split(".");
    if (parts.length !== 4)
	{
        return "error";
    }
	// 提取第一个字节的IP地址来判断类别
    let firstOctet = parseInt(parts[0]);
	// 先判断特殊IP在判断一般IP
	if(firstOctet===127)
	{
		return "本地回环地址";
	}
	else if (firstOctet === 10)
	{
        return "A类私有地址";
    }
	else if(firstOctet === 172 && parseInt(parts[1]) >= 16 && parseInt(parts[1]) <= 31)
	{
		return "B类私有地址";
	}
	else if(firstOctet === 192 && parseInt(parts[1]) === 168 )
	{
		return "C类私有地址"
	}
    else if (firstOctet >= 1 && firstOctet <= 126)
	{
        return "A类地址";
    }
	else if (firstOctet >= 128 && firstOctet <= 191)
	{
        return "B类地址";
    }
	else if (firstOctet >= 192 && firstOctet <= 223)
	{
        return "C类地址";
    }
	else if (firstOctet >= 224 && firstOctet <= 239)
	{
        return "D类地址";
    }
	else if (firstOctet >= 240 && firstOctet <= 255)
	{
        return "E类地址";
    }
        return "error";
}

/**
 * 将BCD码字符串转换为十进制数，包含小数，并且允许出现其他字符，如111 1000 . 1000 0111=78.87
 * @param {String} bcdcode - BCD码字符串，默认值111 1000 . 1000 0111
 * @returns {string} 转换后的数字
 */
   function tfL_BCDcodetodec(bcdcode="111 1000 . 1000 0111")
{
	bcdcode=bcdcode.toString();
	// 去除非0和1的字符
	let filteredBcd = "";
	for (let i = 0; i <=bcdcode.length-1; i++)
	{
	  if (bcdcode[i] === "0" || bcdcode[i] === "1" || bcdcode[i] === ".")
	  {
		filteredBcd += bcdcode[i];
	  }
	}
	// 找到小数点的位置
	let dotIndex = filteredBcd.indexOf(".")
	if(filteredBcd.indexOf(".",dotIndex+1)!==-1) return "error"; // 两个小数点情况
	let dotq="";
	let doth="";
	let i=0,wq=0,wq2=0,val=0,re=0;
	// 提取小数点后的BCD码
	if(dotIndex!==-1)
	{
		doth=filteredBcd.slice(dotIndex+1);
		wq=8;
		wq2=0.1;
		for(i=0;i<=doth.length-1;i++)
		{
			val+=(doth[i]-"0")*wq;
			if(val>=10) return "error";
			re+=(doth[i]-"0")*wq*wq2;
			wq/=2;
			if(wq===0.5)
			{
			 wq=8;
			 wq2*=0.1;
			 val=0;
			}
		}
	}

	val=0;
	// 提取整数BCD码
	if(dotIndex!==-1) dotq=filteredBcd.slice(0,dotIndex);
	else dotq=filteredBcd;
	wq=1;
	wq2=1;
	for(i=dotq.length-1;i>=0;i--)
	{
		val+=(dotq[i]-"0")*wq;
		if(val>=10) return "error";
		re+=(dotq[i]-"0")*wq*wq2;
		wq*=2;
		if(wq===16)
		{
		 wq=1;
		 wq2*=10;
		 val=0;
		}
	}

	return re;
}


/**
 * 计算四边形的面积或周长
 * @param {Number} width - 宽度，默认为40
 * @param {Number} height - 高度，默认为20
 * @param {Boolean} ars - 逻辑值，true则为周长，否则为面积，默认为true
 * @returns 四边形的面积或周长
 */
   function tfL_qua_ar_per(width=40,height=20,ars=true)
{
	width=parseFloat(width);
	height=parseFloat(height);
	ars=Boolean(ars);
	let re;
	if(ars===true) re=(width*2)+(height*2);
	else re=width*height;
	return re;
}


/**
 * 求圆的面积或周长
 * @param {Number} rad - 圆的半径，默认为3
 * @param {Boolean} ars - 逻辑值，true则为周长，否则为面积，默认为true
 * @returns 圆的面积或周长
 */
   function tfL_gar_ar_per(rad=3,ars=true)
{
	rad=parseFloat(rad);
	ars=Boolean(ars);
	let re;
	if(ars===true) re=2*mathcost_pi*rad;
	else re=mathcost_pi*rad*rad;
	return re;
}


/**
 * 提取字符串中指定组数的数字
 * @param {String} str - 要提取数字的字符串，默认24Greater than12
 * @param {Number} cou - 第几组数字，如果小于等于0将返回error，如果没找到将返回0，默认2
 * @returns 字符串中指定组数的数字
 */
   function tfL_withStrHomanum(str="24Greater than12",cou=2)
{
	str=str.toString();
	cou=parseInt(cou);
	if(cou<=0) return "error";
	let c=0,i=0,re=0,sign=1;
	while(i<=str.length-1)
	{
		if(str[i]==="-")
		{
			i++;
			if(str[i]>="0"&&str[i]<="9")
			{
			sign=-1;
			c++;
			if(c!==cou) while(str[i]>="0"&&str[i]<="9"||(str[i]===".")) i++;
			}
		}
		else if(str[i]>="0"&&str[i]<="9")
		{
			sign=1;
			c++;
			if(c!==cou) while(str[i]>="0"&&str[i]<="9"||(str[i]===".")) i++;
		}
		else i++;

		if(c===cou)
		{
			re=parseFloat(str.substring(i))*sign;
			break;
		}
	}
	return re;
}



/**
 * 数位分离，分离出指定位数的数字，只分离整数位
 * @param {Number} nums - 要分离数位的数字，默认123
 * @param {Number} digs - 位数，指的是从右向左多少位，必须大于0，否则返回error，默认2
 * @returns 数字中指定位数的数字
 */
   function tfL_DigSep(nums=123,digs=2)
{
	nums=parseFloat(nums);
	digs=parseInt(digs);
	if(nums===0) return 0;
	if(digs<=0) return "error";
	let re=0,c=0;
	while(nums!==0)
	{
		c++;
		re=nums%10;
		nums/=10;
		nums=Math.floor(nums);
		if(c>=digs) break;
	}
	return re;
}


/**
 * 求出数字的总位数，不包含小数
 * @param {Number} nums - 求位数的数字，默认100
 * @returns 数字的总位数
 */
   function tfL_numDig(nums=100)
{
	nums=parseFloat(nums);
	if(nums===0) return 1;
	let c=0;
	while(nums!==0)
	{
		c++;
		nums/=10;
		nums=Math.floor(nums);
	}
	return c;
}


/**
 * 将一个字符串重复指定次数
 * @param {String} str - 要重复的字符串，默认str
 * @param {Number} cou - 次数，默认2
 * @returns 字符串重复cou后的次数
 */
   function tfL_repStr(str="str",cou=2)
{
	str=str.toString();
	cou=parseInt(cou);
	let i,re="";
	for(i=1;i<=cou;i++) re+=str;
	return re;
}


/**
 * 将字符串左移或右移指定位，例如udentst右移动两位变为student
 * @param {String} str - 要移动的字符串，默认str
 * @param {Boolean} per - 逻辑值，默认true，true为向左移动，false为向右移动
 * @param {Number} num - 左移或右移几位，必须大于等于0，否则返回error，默认1，如果超过字符串长度将会不移动
 * @returns 字符串左移或右移后的结果
 */
   function tfL_strEftOrRight(str="str",per=true,num=1)
{
	str=str.toString();
	per=Boolean(per);
	num=parseInt(num);
	if(num<0) return "error";
	if(num===0||num>=str.length) return str;
	if(per===true)
	{
		return str.substring(num)+str.substring(0,num); // 提取num之后的字符串+0到num的字符串
	}
	else
	{
		return str.substring(str.length-num)+ str.substring(0, str.length - num); // 提取长度减少num的字符串+0到长度减少num的字符串
	}
}


/**
 * 类型转换，将任何值转换成你想要的类型，并返回转换结果
 * @param {any} va - 要转换的值，默认str
 * @param {String} type - 类型，默认string，取值为string，number，bool，int，float中的一种，如果都不对应，将不进行转换，返回原本值
 * @returns 转换结果
 */
   function tfL_type_conve(va="str",type="string")
{
	type=type.toString();
	if(type==="string") return String(va);
	else if(type==="number") return Number(va);
	else if(type==="bool") return Boolean(va);
	else if(type==="int") return parseInt(va);
	else if(type==="float") return parseFloat(va);
	return va;
}


/**
 * 提取字符串中sub1开始到sub2的子字符串，不包括sub1和sub2，如果sub1或sub2不在字符串中，将返回error
 * @param {String} str - 要提取的字符串
 * @param {String} sub1 - 开始的字符串
 * @param {String} sub2 - 结束的字符串
 * @returns 字符串中sub1开始到sub2的子字符串
 */
   function tfL_strsu1tosu2(str="str",sub1="sub1",sub2="sub2")
{
	str=str.toString();
	sub1=sub1.toString();
	sub2=sub2.toString();
	let start=str.indexOf(sub1)+sub1.length;
	let end=str.indexOf(sub2);
	if(start!==-1&&end!==-1)
	{
		return str.substring(start,end);
	}
	return "error";
}



/**
 * 统计子字符串在主字符串中出现的次数，没有出现返回0
 * @param {String} sub - 子字符串
 * @param {String} mastr - 主字符串
 * @returns 子字符串在主字符串中出现的次数
 */
   function tfL_subinmastrcou(sub="sub",mastr="substr")
{
	mastr=mastr.toString();
	sub=sub.toString();
	let cou=0,inde=0;
	while(inde<=mastr.length-1)
	{
		inde=mastr.indexOf(sub,inde);
		if(inde!==-1&&inde<=mastr.length-1)
		{
			cou++;
			inde+=sub.length;
		}
		else return cou;
	}
	return cou;
}

/**
 * 查看主字符串中是否包含子字符串，大写小写分开匹配
 * @param {String} sub - 子字符串
 * @param {String} mastr - 主字符串
 * @returns {boolean}（在）true或（不在）false
 */
   function tfL_substrinmastr(sub="str",mastr="mastr")
{
	mastr=mastr.toString();
	sub=sub.toString();
	if(mastr.indexOf(sub)!==-1) return true;
	return false;
}


/**
 * 字符串提取数字运算
 * @param {String} numstr - 有数字的字符串，如果没有找到，结果会是0（+，-）或1（*，/）
 * @param {String} operator - 运算符， 只能为+，-，*，/，否则会返回error
 */
   function tfL_NumStrToFop(numstr="0+0",operator="+")
{
	numstr=numstr.toString();
	operator=operator.toString();

	let i=0,s=0,sign=1,res=0;

	// 运算符初始值
	if(operator==="+") res=0;
	else if(operator==="-") res=0;
	else if(operator==="*") res=1;
	else if(operator==="/") res=1;
	else return "error";
	let fa=true;  // 专为除法设计的标记
		while(i<=numstr.length-1)
		{
			s=0; // 初始值
			if(numstr[i]==="-")  // 找负号
			{
				i++;
				sign=-1;
				s=parseFloat(numstr.substring(i));
				if(operator==="/"&&fa===true)
				{
					res=(s*sign);
					fa=false;
					s=0;
				}
				i+=s.toString().length;
			}
			else if(numstr[i]>="0"&&numstr[i]<="9") // 找数字
			{

				sign=1;
				s=parseFloat(numstr.substring(i));
				if(operator==="/"&&fa===true)
				{
					res=(s*sign);
					fa=false;
					s=0;
				}
				i+=s.toString().length;
			}
			else i++;
			// 找到了数字就运算
			if(!isNaN(s)&&s!==0)
			{
			if(operator==="+") res+=(s*sign);
			else if(operator==="-") res-=(s*sign);
			else if(operator==="*") res*=(s*sign);
			else if(operator==="/") res/=(s*sign);
			}
		}
	return res;
}


/**
 * 最小公倍数
 * @param {Number} num1 - 第一个数字，默认36
 * @param {Number} num2 - 第二个数字，默认6
 * @returns 两个数的最小公倍数
 */
   function tfL_min_comPe(num1=36,num2=6)
{

	num1=parseFloat(num1);  // 以防引用了字符串数值
	num2=parseFloat(num2);
	let c,d=num1*num2;
	if(num1<num2)
	{
		c=num1;
		num1=num2;
		num2=c;
	}
	while((num1%num2)!==0)
	{
		c=num1%num2;
		num1=num2;
		num2=c;
	}
	return d/num2;
}


/**
 * 最大公约数
 * @param {Number} num1 - 第一个数字，默认12
 * @param {Number} num2 - 第二个数字，默认36
 * @returns 两个数的最大公约数
 */
   function tfL_max_comDor(num1=12,num2=36)
{
	let c;
	num1=parseFloat(num1);  // 以防引用了字符串数值
	num2=parseFloat(num2);
	if(num1<num2)
	{
		c=num1;
		num1=num2;
		num2=c;
	}
	while((num1%num2)!==0)
	{
		c=num1%num2;
		num1=num2;
		num2=c;
	}
	return num2;
}


/**
 * 返回斐波拉切指定项数的值
 * @param {Number} term - 斐波拉切项数，默认1
 * @returns 斐波拉邱项数所对应的值
 */
   function tfL_Fipoachoo(term=1)
{
	term=parseInt(term);
	if(term<=2) return 1;
	let i;
	let a1=1,a2=1,s;
	for(i=3;i<=term;i++)
	{
		s=a1+a2;
		a1=a2;
		a2=s;
	}
	return s;
}


/**
 * 判断素数
 * @param {number} num - 要判断的数字，默认1
 * @return {Boolean} - true为是的，false为不是
 */
   function tfL_isprnum(num=1)
{
	num=parseInt(num);
	if(num<=1) return false;
	let i;
	for(i=2;i<=Math.sqrt(num);i++) if(num%i===0) return false;
	return true;
}


/**
 * 将逻辑值转换为是与不是
 * @param {Boolean} bo - 逻辑值，true或false，默认为false
 * @returns 是或不是
 */
  function tfL_gictocina(bo=false)
{
	bo=Boolean(bo);
	if(bo===true)	return "是";
	return "不是";
}


