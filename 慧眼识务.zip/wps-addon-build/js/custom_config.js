
//这个函数在整个wps加载项中是第一个执行的
function OnAddinLoad(ribbonUI)
{
    // 未知代码，估计是加快界面图片渲染
    if (typeof (window.Application.ribbonUI) != "object")
    {
        window.Application.ribbonUI = ribbonUI
    }

    user_read_Data();
    return true
}

// WPS加载项获取服务URL函数
function GetUrlPath() {
    let e = document.location.toString()
    return -1!=(e=decodeURI(e)).indexOf("/")&&(e=e.substring(0,e.lastIndexOf("/"))),e
}


/**
 * 界面单机事件配置
 * @param cont 界面组件
 * @return {boolean} 运行了返回true，否则返回false
 */
function HY_getAction(cont)
{
    if(U_Action_config[cont.Id]!==undefined)
    {
        U_Action_config[cont.Id]();
        return true;
    }
    return false;
}

/**
 * 界面图片配置
 * @param cont 界面组件
 * @return {*|string} 图片路径
 */
function HY_getmag(cont)
{
    if(U_mag_config[cont.Id]!==undefined) return U_mag_config[cont.Id];
    return U_mag_config["mag_mr"];
}


