/**
 * 随机返回[N,M]范围内的整数 WPS特性，加载项函数参数与实际类型对不上
 * @param {number} numN 起始值
 * @param {number} numM 结束值
 * @returns {number} 随机的整数
 */
function randNtoM(numN, numM)
{
    let renum=0;
    renum += Math.random() * (numM - numN + 1) + numN;
    renum=Math.trunc(renum);
    return renum;
}

/**
 * 数字转换为字母，按表格列名规则
 * @param numb {number} 数字
 * @param big_sma {number} 1小写，2大写
 * @return {string} 转换后的字母，如A，AA，AB
 */
function num_to_ABC(numb,big_sma)
{
    let restr="",i;
    while (numb>=1)
    {
        i=(numb-1)%26;
        if (big_sma===2) restr+=String.fromCharCode(65+i);
        else restr+=String.fromCharCode(97+i);
        numb=Math.trunc((numb-1)/26);
    }
    restr=restr.split("").reverse().join("");
    return restr;
}


/**
 * 普通数字转为罗马数字 最大3999
 * @param num {number} 要转换的普通数字
 * @return {string}
 */
function intToRoman(num)
{
    // 罗马数字的基本字符
    let map = {
        // 10倍数字符与5倍数字符相对应 除了 1000 M

        // 5倍数字符
        5: "V",
        50: "L",
        500: "D",
        // 10倍数字符
        1: "I",
        10: "X",
        100: "C",

        1000: "M"
    }
    // 标识位数 个 十 百 千
    let digits = 1;
    // 结果
    let result = "";
    let current;
    while(num)
    {
        // 取数字最低位
        current = num % 10

        if (current < 4)  // 小于4 就是几个 10倍数字符
        {
            result = map[digits].repeat(current) + result;
        }
        else if (current === 4)  // 等于4 就是IV 10倍数字符+5倍数字符
        {
            result = map[digits] + map[digits * 5] + result;
        }
        else if (current > 4 && current < 9)   // 5-9 7 VII 就是 5倍数字符+几个10倍数字符
        {
            result = map[digits * 5] + map[digits].repeat(current - 5) + result;
        }
        else   // 特殊情况 9 IX 90XC 900CM 进位前就是 低一级加高级 只存在10倍数字符的
        {
            result = map[digits] + map[digits * 10] + result;
        }
        // 换到下一位
        digits *= 10;
        num = Math.trunc(num/10);
    }
    return result;
}

intToRoman(30);