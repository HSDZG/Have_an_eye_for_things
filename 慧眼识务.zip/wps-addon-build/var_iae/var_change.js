
// 简化名称
var Application=window.Application;


// 目录是否被添加的判断标志以及目录表名
var cata_isadd_name="慧眼识务目录表";
