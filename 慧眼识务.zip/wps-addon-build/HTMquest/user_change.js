
// 用户自定义数据
var user_data;


/**
 * 定义用户自定义数据
 */
function defne_userData()
{
    user_data = {
        // 序列添加方向
        // 1为横向，2为竖向
        user_sequ_dire: 2
        ,
        // 英文序列大小写
        // 1为小写，2为大写
        user_sequ_big_sma: 2
        ,
        // 随机数起始
        randomStrart: 0
        ,
        // 随机数结束
        randomEnd: 10
    };
}

/**
 * 用户数据读取
 */
function user_read_Data()
{
    defne_userData();
    if (Application.FileSystem.Exists(Application.Env.GetHomePath() + "/user_data.txt"))
    {

        user_data = JSON.parse(Application.FileSystem.ReadFile(Application.Env.GetHomePath() + "/user_data.txt"));
    }
    else
    {
        console.log(user_data);
        Application.FileSystem.WriteFile(Application.Env.GetHomePath() + "/user_data.txt", JSON.stringify(user_data));

    }
    Application.PluginStorage.setItem("userData", JSON.stringify(user_data));
}



