



user_data=JSON.parse(Application.PluginStorage.getItem("userData"));


/**
 * 加载或刷新用户数据
 */
function oad_userData(userDatas)
{
    if (userDatas!==undefined) user_data=userDatas;
    let sequdom=document.querySelector(".sequs");
    let sequengbig=document.querySelector(".seengbigsm");
    let randstr=document.querySelector(".randomstr");
    let randend=document.querySelector(".randomend");
    sequdom.value=user_data.user_sequ_dire;
    sequengbig.value=user_data.user_sequ_big_sma;
    randstr.value=user_data.randomStrart;
    randend.value=user_data.randomEnd;
}

// HTML网页事件管理函数，这个有关是用户配置的
function seHTJFUN(funname)
{
    switch (funname)
    {
        case "refdata":
        {
            user_data=JSON.parse(Application.PluginStorage.getItem("userData"));
            oad_userData(user_data);
        }break;
        case "saveData":
        {
            Application.FileSystem.WriteFile(Application.Env.GetHomePath()+"/user_data.txt",JSON.stringify(user_data));
            Application.PluginStorage.setItem("userData", JSON.stringify(user_data));
            confirm("保存成功");
        }break;
        case "user_data_htmoad":
        {
            oad_userData(undefined);
        }break;
        case "ch_user_sequ":
        {
            let sequdom=document.querySelector(".sequs");
            user_data.user_sequ_dire=Number(sequdom.value);

        }break;
        case "ch_user_eng_bigsm":
        {
            let sequengbig=document.querySelector(".seengbigsm");
            user_data.user_sequ_big_sma=Number(sequengbig.value);
        }break;
        case "ch_rastr":
        {
            let randstr=document.querySelector(".randomstr");
            user_data.randomStrart=Number(randstr.value);
        }break;
        case "ch_raend":
        {
            let randend=document.querySelector(".randomend");
            user_data.randomEnd=Number(randend.value);
        }break;
        default:
        {
            alert("出现错误");
        }
    }
}
